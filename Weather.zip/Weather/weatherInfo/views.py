import requests
from django.shortcuts import render

# Create your views here.

def index(request):
    url ='http://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=c47da9c50abb590e18e59f6bb32d6bfe'
    city = 'Toronto'

    if request.method == 'POST':
        city_name = request.POST['city_name']
        city = city_name
        
    info = requests.get(url.format(city)).json()
    
    display_info = {
        'city': city,
        'temperature': info['main']['temp'],
        'description': info['weather'][0]['description'],
        'icon': info['weather'][0]['icon']
    }

    weather = {'weather': display_info}
    return render(request, 'weather.html', weather)
