from django.apps import AppConfig


class WeatherinfoConfig(AppConfig):
    name = 'weatherInfo'
